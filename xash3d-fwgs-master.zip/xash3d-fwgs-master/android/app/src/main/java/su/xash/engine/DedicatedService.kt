package su.xash.engine

import android.app.Service
import android.content.Intent
import android.os.IBinder

class DedicatedService : Service() {
	override fun onBind(intent: Intent?): IBinder? {
		TODO("Not yet implemented")
	}
}
